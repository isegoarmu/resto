<?php
include('koneksi.php');

$id_pesan = $_GET['id'];

$sql = "DELETE FROM pesan WHERE id_pesan='$id_pesan'";

$hapus = mysqli_query($koneksi, $sql);

if ($hapus) {
    header("Location: pesan.php?pesan=Data berhasil dihapus!");
    exit;
} else {
    echo "Error: " . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>
