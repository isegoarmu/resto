<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Halaman input biodata</title>
</head>
<body>
<h3>MASUKKAN MENU</h3>
<a href="index.php" style="padding :0.4% 0.8%;background-color :Red; color :yellow; border-radius: 2px; text-decoration : none;">
MASUKKAN MENU</a><br><br>
<form action= " " method="POST">
    <table>
        <tr>
            <td>ID MENU : <br></td>
            <td><input type="text" name="id_menu" place holder = "id_menu" required></td>
        </tr>
        <tr>
            <td>NAMA MENU : <br></td>
            <td><input type="text" name="nama_menu" place holder = "nama_menu" required></td>
        </tr>
      
        <tr>
            <td>KATEOGRI : <br></td>
            <td><input type="text" name="kategori" place holder = "kategori" required></td>
        </tr>

        <tr>
            <td>HARGA : <br></td>
            <td><input type="text" name="harga" placeholder = "harga" required></td>
        </tr>

        <tr>
            <td></td>
            <td></td>
            <td><input type="submit" name="simpan" value="simpan"></td>
        </tr>
    </table>
</form>
<?php
include "koneksi.php";
if(isset($_POST['simpan'])){
$insert =mysqli_query($koneksi,"insert into menu values
                     ('".$_POST['id_menu']."',
                     '".$_POST['nama_menu']."',
                     '".$_POST['kategori']."',
                     '".$_POST['harga']."')");
                     if($insert){
                        echo "berhasil disimpan";
                     }else{
                        echo "gagal ditampilkan";
                     }

}?>
</body>
</html>