<?php
include('koneksi.php');

$id = $_POST['id_petugas'];
$nama = $_POST['nama_petugas'];
$jenkel = $_POST['jenkel'];
$username = $_POST['username'];
$password = $_POST['password'];
$sql = "update petugas set nama_petugas='$nama', jenkel='$jenkel', username='$username', password='$password' where id_petugas='$id'";
$simpan = mysqli_query($koneksi, $sql);
if ($simpan) {
    header("location:petugas.php?pesan=Berhasi Ubah Data!");
}
