<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Halaman input biodata</title>
</head>
<body>
<h3>INPUT PELANGGAN</h3>
<a href="index.php" style="padding :0.4% 0.8%;background-color :Red; color :yellow; border-radius: 2px; text-decoration : none;">
PELANGGAN</a><br><br>
<form action= " " method="POST">
    <table>
        <tr>
            <td>ID PELANGGAN : <br></td>
            <td><input type="text" name="id_pelanggan" place holder = "id_pelanggan" required></td>
        </tr>
        <tr>
            <td>NAMA PELANGGAN : <br></td>
            <td><input type="text" name="nama_pelanggan" place holder = "nama_pelanggan" required></td>
        </tr>
      
        <tr>
            <td>ALAMAT : <br></td>
            <td><input type="text" name="alamat" place holder = "alamat" required></td>
        </tr>

        <tr>
            <td>NOMOR TELEPHONE : <br></td>
            <td><input type="text" name="tlp" placeholder = "tlp" required></td>
        </tr>

        <tr>
            <td></td>
            <td></td>
            <td><input type="submit" name="simpan" value="simpan"></td>
        </tr>
    </table>
</form>
<?php
include "koneksi.php";
if(isset($_POST['simpan'])){
$insert =mysqli_query($koneksi,"insert into pelanggan values
                     ('".$_POST['id_pelanggan']."',
                     '".$_POST['nama_pelanggan']."',
                     '".$_POST['alamat']."',
                     '".$_POST['tlp']."')");
                     if($insert){
                        echo "berhasil disimpan";
                     }else{
                        echo "gagal ditampilkan";
                     }

}?>
</body>
</html>