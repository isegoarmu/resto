<!DOCTYPE html>
<html>
<head>
  <title>Restaurant Location</title>
  <link rel="stylesheet" type="text/css" href="about.css">
</head>
<body>
  <header>
    <h1>LETAK LOKASI RESTAURANT</h1>
  </header>

  <main>
    <div id="map"></div>
  </main>

  <footer>
    <p>&copy; <?php echo date("Y"); ?> REFRAN`Z Restaurant. All rights reserved.</p>
  </footer>

  <script src="https://goo.gl/maps/fVL32GGxjquzjG8E9" async defer></script>
  <script src="about.js"></script>
</body>
</html>
