<?php

require("koneksi.php");
$id_menu = $_GET['id'];
$query = mysqli_query($koneksi, "select * from menu where id_menu='$id_menu'");
$data = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="stylesheet" href="anak.css">
<body>
    
<h3>Ubah Data</h3>
<form action="emenu.php" method="POST" enctype="multipart/form-data">
ID MENU: <br>
<input type="text" name="id_menu" value="<?php echo $data['id_menu']; ?>" readonly><br><br>
NAMA MENU : <br>
<input type="text" name="nama_menu" value="<?php echo $data['nama_menu']; ?>"><br><br>

KATEGORI : <br>
<input type="text" name="kategori" value="<?php echo $data['kategori']; ?>"><br><br>
HARGA : <br>
<input type="text" name="harga" value="<?php echo $data['harga']; ?>"><br><br>
<button type="submit">Simpan</button>

</form>
</body>
</html>