<?php
include("koneksi.php");
$username = $_POST['txtusername'];
$password = $_POST['txtpassword'];
$sql = "select * from petugas where username='$username' and password='$password'";
$aksi = mysqli_query($koneksi, $sql);
$banyak = mysqli_num_rows($aksi);
if ($banyak >= 1) {
$data = mysqli_fetch_assoc($aksi);
session_start();
$_SESSION['username'] = $data['username'];
header("location:index.php");
} else {
header("location:login.php?error=username/password masih salah");
}
