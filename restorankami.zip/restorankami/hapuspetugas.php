<?php
include("koneksi.php");
$id = $_GET['x'];

$sql = "delete from petugas where id_petugas='$id'";
$aksi = mysqli_query($koneksi, $sql);
if ($aksi) {
    header("location:petugas.php?pesan=Berhasil Hapus Data");
}
