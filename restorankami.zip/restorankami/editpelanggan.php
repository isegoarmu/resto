<?php
// Include the database connection
require("koneksi.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the submitted data
    $id_pelanggan = $_POST['id_pelanggan'];
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $tlp = $_POST['tlp'];

    // Update the customer information in the database
    $query = "UPDATE pelanggan SET nama_pelanggan='$nama_pelanggan', alamat='$alamat', tlp='$tlp' WHERE id_pelanggan='$id_pelanggan'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        // Redirect to the customer list page
        header("Location: pelanggan.php");
        exit;
    } else {
        echo "Error updating customer information: " . mysqli_error($koneksi);
    }
}

// Retrieve the customer ID from the URL parameter
$id_pelanggan = $_GET['id_pelanggan'];

// Fetch the customer data from the database
$query = "SELECT * FROM pelanggan WHERE id_pelanggan='$id_pelanggan'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Customer</title>
    <link rel="stylesheet" href="anak.css">
</head>
<body>
    <h2>Edit Customer</h2>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        ID PELANGGAN :
        <input type="text" name="id_pelanggan" value="<?php echo $data['id_pelanggan']; ?>"><br><br>
        <label for="nama_pelanggan">Nama Pelanggan:</label>
        <input type="text" name="nama_pelanggan" value="<?php echo $data['nama_pelanggan']; ?>"><br><br>
        <label for="alamat">Alamat:</label>
        <input type="text" name="alamat" value="<?php echo $data['alamat']; ?>"><br><br>
        <label for="tlp">Nomor Telepon:</label>
        <input type="text" name="tlp" value="<?php echo $data['tlp']; ?>"><br><br>
        <input type="submit" value="Update">
    </form>
</body>
</html>
