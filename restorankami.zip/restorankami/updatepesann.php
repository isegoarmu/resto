<?php
require("koneksi.php");
$id_pesan = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM pesan WHERE id_pesan='$id_pesan'");
$data = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Data</title>
</head>
<body>
    <h3>Ubah Data</h3>
    <form action="updatepesan.php" method="POST" enctype="multipart/form-data">
        ID PESAN : <br>
        <input type="text" name="id_pesan" value="<?php echo $data['id_pesan']; ?>"><br><br>
        ID MENU : <br>
        <input type="text" name="id_menu" value="<?php echo $data['id_menu']; ?>"><br><br>
        QUANTITY : <br>
        <input type="text" name="qty" value="<?php echo $data['qty']; ?>"><br><br>
        SUB TOTAL : <br>
        <input type="text" name="sub_total" value="<?php echo $data['sub_total']; ?>"><br><br>
        ID PELANGGAN : <br>
        <input type="text" name="id_pelanggan" value="<?php echo $data['id_pelanggan']; ?>"><br><br>
        TANGGAL PESAN : <br>
        <input type="date" name="tgl_pesan" value="<?php echo $data['tgl_pesan']; ?>"><br><br>
        NOMOR MEJA : <br>
        <input type="text" name="meja" value="<?php echo $data['meja']; ?>"><br><br>
        <button type="submit">Simpan</button>
    </form>
</body>
</html>
