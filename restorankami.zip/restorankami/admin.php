<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="register.css">
  <link rel="stylesheet" href="crud.css">
  <script src="main.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">REFRAN`Z RESTO</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li class="active"><a href="about.php">About</a></li>
      <li class="active"><a href="contact.php">Contacts</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Menu<span class="caret"></span></a>
        <ul class="dropdown-menu">
        <li><a href="menu.php">Menu</a></li>
          <li><a href="pelanggan.php">Pelanggan</a></li>
          <li><a href="pesan.php">Pesan</a></li>
          <li><a href="petugas.php">Petugas</a></li>
        </ul>
      </li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
    <li><a href="user.php"><span class="glyphicon glyphicon-user"></span>user</a></li>  
    <li><a href="admin.php"><span class="glyphicon glyphicon-user"></span> Register</a></li>
      <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
    
                <h3 class="text-center">Register Akun </h3>
                <form action="sadmin.php" method="POST">
                    <div class="mb-3">
                    ID_Petugas : <br>
                        <input type="text" class="form-control" name="id_petugas"></div><br>
                    Nama petugas :<br>
                        <input type="text" class="form-control" name="nama_petugas"></div><br>
                    Jenis Kelamin :
                        <select class="form-control" name="jenkel">
                            <option>Pilih</option>
                            <option value="Laki laki">Laki laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>        
                    Username : <br>
                        <input type="text" class="form-control" name="txtusername"></div><br>
                    Password : <br>
                        <input type="password" class="form-control" name="txtpassword"><br>
                    <button type="submit" class="btn btn-primary">Masuk</button>
           
</body>

</html>