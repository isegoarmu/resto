document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault();
    // Perform additional validation or submission logic here
    alert("Form submitted!");
  });
  