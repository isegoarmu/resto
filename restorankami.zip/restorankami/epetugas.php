<?php 
include("koneksi.php"); 
$id_akun = $_POST['idakun']; 
$username = $_POST['username']; 
$password = $_POST['password']; 
$sql = "update petugas set username='$username', password='$password' where id_akun='$id_akun'";
$exe = mysqli_query($koneksi, $sql); 
