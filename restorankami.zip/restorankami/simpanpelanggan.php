<?php
 include("koneksi.php");
 $id_pelanggan= $_POST['id_pelanggan'];
 $nama_pelanggan = $_POST['nama_pelanggan'];
 $alamat = $_POST['alamat'];
 $tlp = $_POST['tlp'];
$sql = "insert into pelanggan values ('$id_pelanggan','$nama_pelanggan','$jenkel','$alamat','$tlp')";
 $proses  = mysqli_query($koneksi, $sql);
 if ($proses) {
 header("location:index.php");
 }