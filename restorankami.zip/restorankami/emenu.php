<?php
include('koneksi.php');

$id_menu = $_POST['id_menu'];
$nama_menu = $_POST['nama_menu'];
$kategori = $_POST['kategori'];
$harga = $_POST['harga'];
$sql = "UPDATE menu SET nama_menu='$nama_menu', kategori='$kategori', harga='$harga' WHERE id_menu='$id_menu'";
$simpan = mysqli_query($koneksi, $sql);
if ($simpan) {
    header("location:menu.php?pesan=Berhasil Ubah Data!");
}
?>
